# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.1.0 (2022-11-02)

### Features

- **widget-tiktok-pixel:** add tiktok pixel widget ([#806](https://github.com/ecomplus/storefront/issues/806)) ([13e1e77](https://github.com/ecomplus/storefront/commit/13e1e77a745c69033a3c3176e7f34e225db2d313))

# Change Log
